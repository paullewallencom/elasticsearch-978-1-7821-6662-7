elasticsearch-cookbook
======================

PacktPub ElasticSearch CookBook code repository
